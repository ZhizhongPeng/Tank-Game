package main;

import frame.Mainframe;

public class main {
	public static void main(String[] args) {
		Mainframe frame = new Mainframe();// create frame
		frame.setVisible(true);// show frame
	}
}
