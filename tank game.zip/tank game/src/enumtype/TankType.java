package enumtype;

public enum TankType {
       PLAYER_1,
       
       PLAYER_2,
       
       BOTTANK
       
}
