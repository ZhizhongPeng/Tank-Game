package enumtype;

public enum GameType {
        SINGLE_PLAYER,
        
        DUAL_PLAYER      
}
